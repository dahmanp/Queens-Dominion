Wednesday font is free for personal use.

This font was created and distributed by FontGet.com. You may freely distribute this font however you must credit FontGet.com if you do.